import Foundation

//Operador de asignacion
let opAsignacion = "El operador de asignacion corresponde al = para asignar un valor"

var valor1 = 15
valor1 += 5 //+= es como decir valor1 = valor1 + 5 (15 + 5) y lo almacena en la misma variable
valor1 -= 5 //valia 20 y ahora vale 15
//y asi con el resto de los operadores


//Operadores Aritmeticos
var value1 = 10
var value2 = 3
var value3 = 10
var result = 0

result = value1 + value2 //Operador Suma
result = value1 - value2 //Operador Resta
result = value1 * value2 //Operador Multiplicacion
result = value1 / value2 //Operador Division (En este caso es de enteros, no va a dar con coma)
result = value2 % value2 //Operador Resto de division
result = -value1 //Hacer negativo el numero que era positivo
//Swift no deja hacer operaciones entre tipos distintos Ej: Int dividido Double
//La forma correcta es esta:
let double1: Double = 10 //No lo escribo como un double con "." pero le digo que es de ese tipo
let double2 = 3.0
let validResult = double1 / double2


//Operadores de Comparacion
var booleanResult = (value1 == value3)
booleanResult = (value1 != value3)
booleanResult = (value1 > value2)
booleanResult = (value1 < value2)
booleanResult = (value1 <= value3)


//Operadores Logicos booleanos
let booleanTrue = true
let booleanFalse = false

var booleanNegativeTrue = !booleanTrue
var booleanNegativeFalse = !booleanFalse

booleanResult = booleanTrue && booleanFalse //false

booleanResult = booleanTrue || booleanFalse //true


//Operadores de Rango
var closedRange = 1...5 //contiene ambos extremos
var semiOpenedRange = 1..<5 //del 1 al 4 (no incluye el 5)
var rightOneSideRange1 = ...5 //entre -infinito y 5
var rightOneSideRange2 = ..<5 //entre -infinito y 4
var leftOneSideRange = 5... //entre el 5 e infinito

var checkNumber = 5
var estaEnRango = closedRange.contains(checkNumber)
var estaEnRango2 = closedRange.contains(6)
//con esto podemos checkear si un numero solicitado esta dentro del rango


//Operadores Ternarios
var operation1Result = 50
var operation2Result = 75
var maxResult = (operation1Result > operation2Result) ? "Es verdadero" : "Es falso"

var nota1: Double? = 5.4
var nota2: Double? = nil

var nota1Presente = (nota1 != nil) ? nota1! : 0
// nota es distinto a nil ? verdadero: nota1 - falso: 0
var nota2Presente = (nota2 == nil) ? 0 : nota2!
// nota2 es igual a nil ? verdadero: 0 - falso: nota2
var promedio = (nota1Presente + nota2Presente) / 2
