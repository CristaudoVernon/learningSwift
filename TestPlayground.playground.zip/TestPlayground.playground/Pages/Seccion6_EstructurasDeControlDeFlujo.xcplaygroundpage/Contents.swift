import Foundation

//If - Else
let valor1 = 50
let valor2 = 100

if valor1 > valor2 {
    "\(valor1) es mayor"
}else{
    "\(valor2) es mayor"
    
}

//Else If
let nota1 = 4.9
var califStr: String

if nota1 < 5.0{
    califStr = "Desaprobado"
}else if nota1 >= 5.0{
    califStr = "Aprobado"
}else if nota1 == 10{
    califStr = "Sobresaliente"
}


var stock = 100
var comprasPendientes = 0
var cantItemsComprados: Int? = nil

if let unwrappedCantItemsComprados = cantItemsComprados {
    stock -= unwrappedCantItemsComprados
}else{
    comprasPendientes += 1
}

let finalStock = stock
let finalComprasPendientes = comprasPendientes

/*En el if hace dos cosas: 1) detecta si cantItemsComprados es nil o no. 2) Si no es nil, guardamelo en la variable unwrappedCantBlaBlabla
 ¿por que ya de por si es una comparacion?
    porque unwrapedBlaBlaBla no es un opcional y cantItemsComprados si.
    Si cantItemsComprados ya tiene un valor dentro es posible almacenarlo en unwrapedBlaBlaBla.
    Si cantItemsComprados fuese nil, no podria ser almacenado en unwrappedCantBlablalba porque
    este ultimo no es de tipo opcional*/


//Switch - Case - Default
let calificacion = 7.8
let califStr2: String
var notificar: Bool

switch calificacion {
case ..<1.0:
    califStr2 = "Entrega en blanco"
    notificar = true
case ..<5.0:
    califStr2 = "Desaprobado"
case ..<7.0:
    califStr2 = "Aprobado"
case ..<9.0:
    califStr2 = "Aprobadisimo"
default:
    califStr2 = "un 10"
}
/*En Swift el Switch no lleva la palabra resevada Break, en cambio si queremos que se ejecuten todos como en cualquier otro lenguaje necesitamos usar la palabra reservada "fallthrough"*/


//Bucles for - in
for iterationNumber in 1...5{
    print("Iteracion numero: " + String(iterationNumber))
}


var sumaTotal = 0

for numero in 1...15{
    sumaTotal += numero
}
sumaTotal


var numeroPar = 0

for otherNumero in 1...1000{
    if (otherNumero % 2 == 0){
        numeroPar += otherNumero
    }else{
        continue
    }
}
numeroPar

let names = ["Anna", "Alex", "Brian", "Jack"]
for name in names {
    print("Hello, \(name)!")
}

//Bucles While

var acumulacionFactorial = 1
var iteracionActual = 2
let numbercitou = 50

while (iteracionActual <= numbercitou) && (acumulacionFactorial <= 1_000){
    acumulacionFactorial *= iteracionActual
    iteracionActual += 1
}

acumulacionFactorial
var finalIteracionActual = (iteracionActual - 1)


//Bucles Repeat - While
var segundosParaLanzamiento = 5
var countdown = ""

repeat{
    let nextText: String
    
    if segundosParaLanzamiento > 0 {
        nextText = String(segundosParaLanzamiento)//muestra los numeros como string
    }else{
        nextText = "Despegue!" //cuando llegue a 0 pasa por el else y muestra "Despegue!"
    }
    
    if countdown != "" {  //si el countdown es distinto a vacio...
        countdown += ", " // ...al countdown sumale una coma al final
    }
    
    countdown += nextText
    segundosParaLanzamiento -= 1 //descontamos de a 1 para llegar a 0
    
}while segundosParaLanzamiento >= 0

countdown

//Siempre se va a ejecutar al menos una vez antes de pasar por el while
