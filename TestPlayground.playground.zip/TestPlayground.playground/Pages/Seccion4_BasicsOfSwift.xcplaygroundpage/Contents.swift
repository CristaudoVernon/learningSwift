import Foundation

//barra invertida para copiar \

//variables
var greeting = "Hello, playground"

let numerito = 23

//Variables explicitas
var explicitString: String = "String explicito"

var explicitInt: Int = 420
var explicitInt2: Int = -420
var normalUint: UInt = 42 //Solo pueden ser valores positivos

var intLarguito: Int = 232_3434_234 //esto es para que sea legible

var numeroFloat: Float = 4.26786_686876 //redondea despues del 7mo
var numeroDouble: Double = 4.232353445634575_6456

//Boolean
var valorTrue = true
var valorFalse = false

var explicitTrue: Bool = true
var explicitFalse: Bool = false

//Strings and Char
var stringcito = "Esto es un string"
var stringExplicito: String = "Esto es un string explicito"

var multiLineString: String = """
Este String tiene multiple lineas
y ESTA es la segunda linea
"""

var stringDeCaracteresEspeciales: String = "Otro texto con multiples lineas\nesta es la segunda linea"

var tipoChar: Character = "a"

//Arrays o Listas
var listaInt: [Int] = [4, 2, 0, 6, 9]
var otraListaInt: Array<Int> = [2, 4, 1, 9]

var inferedIntList = [2, 9, 5, 7, 4]

listaInt.append(8) //agrega al final de la lista
listaInt.insert(7, at: 3) // agrega X at position X

//Diccionarios

var stringIntDictionary: [String: Int] = [
    "Uno": 1, //Clave-Valor
    "Dos": 2,
    "Tres": 3
]

var otherStringInDictionary: Dictionary<String, Int> = [
    "Uno": 1,
    "Dos": 2,
    "Tres": 3
]

var valueUno = stringIntDictionary["Dos"]

stringIntDictionary["Cuatro"] = 4
var verDiccionarioModificado = stringIntDictionary

var intSet: Set<Int> = [2, 4 , 5, 8, 8]
var otherIntSet: Set<Int> = [8, 7, 2, 3]
var intersectionSet = intSet.intersection(otherIntSet)
//en este es para mostrar los elementos en comun entre dos sets

var unirSets = intSet.union(otherIntSet)

var differenceSet = intSet.symmetricDifference(otherIntSet)
//en este es para mostrar los elementos que no estan en comun entre ambos sets

//Tuplas
var simpleTuple: (Int, String) = (4, "String")

var elementZero = simpleTuple.0 //acceder al valor posicion 0
var elementOne = simpleTuple.1

var tupleWithNames: (value: Int, write: String) = (value: 5, write: "cinco")

let tupleElement0 = tupleWithNames.0
let tupleElementByValue = tupleWithNames.value
let tupleElementByWrite = tupleWithNames.write
//estas son las diferentes formas de acceder a los valores

//Tipo Opcional
var optionalInt: Int? = 42 //la interrogacion es de tipo opcional

optionalInt = nil

var implicitOpcional: Int! = nil

optionalInt = 50 //si puede tomar un valor despues de un nil (siempre y cuando tenga el ? en su variable explicita (ver linea 94)
