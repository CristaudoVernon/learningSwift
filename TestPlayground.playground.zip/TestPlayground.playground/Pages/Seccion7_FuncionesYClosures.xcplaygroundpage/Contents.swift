import Foundation

//Funciones
func myFunc() {
    var totalSuma = 0
    
    for number in 1..<100{
        totalSuma += number
    }
}

myFunc()

func first100NumberAdd() -> Int { //devuelve un Int
    var totalSuma = 0
    
    for number in 1...100{
        totalSuma += number
    }
    return totalSuma
}

var totalSuma = first100NumberAdd()
print("Total suma 1: " + String(totalSuma))


//Funcion con parametros
func sumarNumeros(stopNumber: Int) -> Int {
    var totalSuma = 0
    
    for number in 1...stopNumber{
        totalSuma += number
    }
    return totalSuma
}

totalSuma = sumarNumeros(stopNumber: 420)
print("Total suma por parametro: " + String(totalSuma))

//otro ejemplo
func saludar(nombre: String){
    print("Hola " + nombre)
}

saludar(nombre: "jose")//aca llamo a esa funcion y le doy el parametro de tipo string "Jose"


//Valores de parametros por defecto

func sumarNumerosConDefaultParam(numeroFinal: Int = 68) -> Int{
    var totalSuma2 = 0
    
    for number in 1...numeroFinal{
        totalSuma2 += number
    }
    return totalSuma2
}
var totalSuma2 = sumarNumerosConDefaultParam()
print("Total suma con parametro default: " + String(totalSuma2))

totalSuma2 = sumarNumerosConDefaultParam(numeroFinal: 420)
print("Total suma con parametro default dado al final: " + String(totalSuma2))

//Diferencia entre etiqueta de argumento y nombre de parametro 
func pow(_ base: Int, toThePowerOff exponent: Int) -> Int { //dentro:exponent y fuera powerOff
    var result = base
    for _ in 1..<exponent { //este _ es otro, no tiene nada que ver con el del parametro de pow
        result *= base
    }
    return result
}
//Como no tiene un parametro que voy a usar afuera, ni se gasta en ponerle nombre
let numberPower = pow(2, toThePowerOff: 10)
print("Potencia 1: " + String(numberPower))
//esto es para que sea mas expresiva la funcion, entonces sabemos para que parte sirve cada parametro, si dentro o fuera de la funcion


//Closures (bloques de codigo)

var myClosure = {(value: Int) -> Int in //no lleva nombre, se asigna a una variable
    print("Value \(value)")
    return value
}
myClosure(2)


var closureDuplicarValor = { (numero: Double) -> Double in
    return numero * 2.0
}
closureDuplicarValor(4.5) //no tuve que poner el tipo de parametro (Double: 4.5)


var closureSumarleUno: (Int) -> Int /*fuera*/ = { (numero: Int) -> Int in /*dentro*/
    return numero + 1
}
closureSumarleUno(3)


//inferencia del tipo de los parametros y valor devuelto de un closure
let otherDivider: (_ dividend: Double, _ divisor: Double) -> Double? = { myDividend, myDivisor in
    if myDivisor == 0{
        return nil
    }
    return myDividend / myDivisor
}
otherDivider(20, 0)


let otroDivisor: (_ dividendo: Double, _ divisor: Double) -> Double? = {
    if $1 /*divisor*/ == 0 {
        return nil
    }
    return $0/*dividendo*/ / $1 /*divisor*/
}
otroDivisor(20, 2)


let divisorTernario: (_ dividendo: Double, _ divisor: Double) -> Double? = {
    ($1 == 0) ? nil : $0 / $1
}
divisorTernario(12, 2)



//Closures y Funciones como parametros de Funciones
func suma(valor1: Int, valor2: Int) -> Int {
    return valor1 + valor2
}

func resta(valor1: Int, valor2: Int) -> Int {
    return valor1 - valor2
}

func multiplicacion(valor1: Int, valor2: Int) -> Int {
    return valor1 * valor2
}

func division(dividendo: Int, divisor: Int) -> Int {
    return (divisor == 0) ? 0 : dividendo / divisor
}

func calculadora(_ valor1: Int, _ valor2: Int, _ operacion:(Int, Int) -> Int) -> Int {
    //operacion es la funcion creada dentro de la funcion, va a recibir dos parametros de tipo int
    return operacion(valor1, valor2)
    //esos dos parametros de tipo int van a ser valor1 y valor2 que son de la funcion principal
}
calculadora(4, 2, multiplicacion)
