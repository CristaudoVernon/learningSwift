import Foundation

//Que opciones de tipos de datos tenemos en Swift?

//Estructuras
struct PostalAdress {
    let adressLine1: String
    let adressLine2: String
    let zipCode: String
    let city: String
    
    init(initialAdressLine1: String, initialAdressLine2: String, initialZipCode: String, initialCity: String) {
        
        adressLine1 = initialAdressLine1
        adressLine2 = initialAdressLine2
        zipCode = initialZipCode
        city = initialCity
    }
    
    //metodos
    func completeAdress() -> String {
        var result = self.adressLine1
        result += " "
        result += adressLine2
        result += " "
        result += zipCode
        result += " "
        result += city
        
        return result
    }
}

//Clases
class Thermostat {
    var temperature: Double
    
    init(initialTemperature: Double) {
        temperature = initialTemperature
    }
    
    func increaseTemperature(_ degrees: Double) {
        temperature += degrees
    }
}


//Enumerados
enum CardinalPoint {
    case north
    case east
    case south
    case west
    
    var firstCardinalPoint: CardinalPoint {
        get {
            return .north
        }
    }
    
    init(direction: CardinalPoint) {
        self = direction
    }
    
    func counterClockwise() -> CardinalPoint {
        switch self {
        case .north:
            return .east
            
        case .east:
            return .south
            
        case .south
            return .west
            
        case .west
            return .north
        }
    }
}
